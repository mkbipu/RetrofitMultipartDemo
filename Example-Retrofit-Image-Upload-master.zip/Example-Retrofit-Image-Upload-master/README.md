# Example-Retrofit-Image-Upload
Example For Simple Image Upload in Android by Using Retrofit 2

https://medium.com/@adinugroho/upload-image-from-android-app-using-retrofit-2-ae6f922b184c#.fg38trc42
